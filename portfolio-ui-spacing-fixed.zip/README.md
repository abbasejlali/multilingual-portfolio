# Multilingual Portfolio (Next.js)

A responsive personal portfolio built with **Next.js 13**, **React 18**, **Tailwind CSS**, and **Framer Motion**. English is the default language and uses left-to-right (LTR) layout. Persian is also supported and switches the document and layout to right-to-left (RTL).

## Features

- English-first experience with Persian language switching.
- Language choice is saved in `localStorage` and restored on the next visit.
- Correct document metadata (`lang` and `dir`) updates when the language changes.
- Responsive desktop sidebar and mobile navigation.
- Light/dark theme toggle styled to match the site surfaces, borders, and rounded controls.
- Responsive spacing for project metadata and social-share controls.
- Responsive development/language skill columns with an explicit gap on desktop and mobile.
- Animated cursor follower on devices with a fine pointer; disabled for touch devices and reduced-motion preferences.
- Responsive portfolio, services, blog, about, and contact pages.
- Local fonts and image assets.

## Requirements

- Node.js 18.17 or later (Node.js 20 LTS recommended).
- npm 9 or later.

## Getting started

```bash
git clone <your-repository-url>
cd <repository-folder>
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Scripts

```bash
npm run dev    # Start the development server
npm run lint   # Run Next.js ESLint checks
npm run build  # Create a production build
npm start      # Serve the production build
```

Run `npm run build` before deploying. Run `npm run lint` to check code quality.

## Project structure

```text
src/
  components/
    layout/       Shared site layout
    module/       Header, cards, counters, and reusable UI modules
    template/     Page-level UI templates
  pages/          Next.js Pages Router routes
  styles/         Global styles, direction and cursor behavior
  utils/          Translation provider, profile data, fonts, cursor follower
public/
  Fonts/          Local font files
  imgs/            Portfolio imagery and SVG assets
```

## Internationalization (i18n)

Translations live in `src/utils/i18n.js` under the `messages.en` and `messages.fa` dictionaries. Use `useLanguage()` in a component:

```jsx
import { useLanguage } from "@/utils/i18n";

export default function Example() {
  const { language, setLanguage, t } = useLanguage();
  return <button onClick={() => setLanguage(language === "en" ? "fa" : "en")}>{t("contact")}</button>;
}
```

When adding visible copy, add a translation key to **both** dictionaries and render it through `t("key")`. Avoid hardcoded user-facing strings in page components. The provider updates `document.documentElement.lang` and `document.documentElement.dir`; English is `en`/`ltr`, and Persian is `fa`/`rtl`.

Prefer logical CSS properties and Tailwind logical utilities (`ms-*`, `me-*`, `ps-*`, `pe-*`, `start-*`, `end-*`, and `float-start`/`float-end`) instead of physical left/right utilities. The fixed desktop sidebar is reserved in document flow: it appears on the left for English and on the right for Persian, while `.page-content` takes only the remaining width. Page sections should use `w-full`, not `w-screen`, so they do not stretch underneath the sidebar. For flex layouts, verify both `dir="ltr"` and `dir="rtl"` at desktop and mobile widths.

## Cursor animation

The cursor follower uses Framer Motion motion values and springs. It reads `clientX`/`clientY` from `mousemove`, so the coordinates match fixed viewport positioning while scrolling. The component is mounted outside the clipped page section to avoid being cut off by `overflow: hidden`.

The effect is intentionally disabled when `(pointer: coarse)`, hover is unavailable, or `prefers-reduced-motion: reduce` is enabled. Test in Chromium, Firefox, and Safari/WebKit; custom cursors should never block clicks or keyboard interaction.

## Customization checklist

1. Update profile details and contact information in `src/utils/infojson.js` and the page templates.
2. Replace sample portfolio/blog entries and sample testimonials with real content before publishing.
3. Update social links in `src/components/template/HomePage.jsx` and share links in detail templates.
4. Add any new visible text to both translation dictionaries.
5. Check all routes in both languages and in light/dark themes.
6. Test at mobile, tablet, and desktop widths, and test keyboard navigation.
7. Run `npm run lint` and `npm run build` before deployment.

## Deployment

The project can be deployed to Vercel or any host that supports a Next.js production server. For a standard Node deployment:

```bash
npm install
npm run build
npm start
```

Configure the hosting platform to use the supported Node.js version. Do not commit `.env` files, secrets, build output, or `node_modules`.

## Browser and accessibility notes

- The app uses standard `dir` and `lang` document attributes.
- Reduced-motion preferences are respected by the custom cursor and global motion styles.
- The language selector exposes the selected option with `aria-pressed`.
- Please test interactions in current Chrome/Edge, Firefox, and Safari versions before release.

## License

Add a license file before publishing if you want others to reuse, modify, and distribute this project. Also confirm that all included images, fonts, and other assets are licensed for redistribution.

## RTL/LTR layout behavior

- English (`en`) is the default locale and uses left-to-right layout. Persian (`fa`) uses right-to-left layout. The active direction is applied to the app shell, content area, sidebar, detail pages, and testimonial sliders.
- Sidebar content alignment is explicit per locale: English is left-aligned and Persian is right-aligned. On desktop, the main content reserves the sidebar width on the correct logical side.
- Testimonials/comments use normal document flow instead of floats. The avatar-to-author spacing uses `gap`, so the spacing remains between the image and text in both directions.
- Icon-and-label groups use flex/grid `gap` so spacing stays between elements in both directions. Project details metadata is vertically grouped, and the Share controls have consistent touch targets and gaps.
- The About page skill groups use two equal columns with a logical horizontal gap on desktop and a vertical gap on smaller screens.
- The dark-mode toggle uses the same rounded surface, subtle border, shadow, and dark surface colors as the existing navigation UI.
- When adding new components, prefer CSS logical properties (`margin-inline-start`, `padding-inline-end`, `inset-inline-start`) and flex/grid `gap`. Avoid hard-coded `ml-*`, `mr-*`, `left-*`, and `right-*` unless the direction is intentionally physical.
